import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    private JTextField pantalla;
    private JButton calcularButton;
    private JPanel MainPanel;
    double GradosC, GradosF;
    public Main () {
        setContentPane(MainPanel);
        setTitle("Conversor De Grados");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setVisible(true);
        calcularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(pantalla.getText().length() > 0 ) {
                    GradosC = Double.parseDouble(pantalla.getText());
                    GradosF = (GradosC * 1.8) + 32;


                }
                JOptionPane.showMessageDialog(Main.this, GradosF);

            }
        });
    }

    public static void main(String[] args) {
        new Main();

    }
}
